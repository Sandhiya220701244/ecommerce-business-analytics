# E-Commerce Sales & Customer Analytics

A beginner-friendly, Python-first data analytics portfolio project using the **Brazilian E-Commerce Public Dataset by Olist**.

The goal is to answer practical business questions with Python and pandas, explain the findings clearly, and build a project that can be extended with SQL and a dashboard later.

## Business questions

1. How do order volume and revenue change over time?
2. Which product categories contribute the most revenue?
3. Which Brazilian states generate the most orders and revenue?
4. How often are orders delivered later than the estimated date?
5. Is delivery lateness associated with lower review scores?

## Dataset

Use the Brazilian E-Commerce Public Dataset by Olist, available on Kaggle:

https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce

Download the CSV files and place them in `data/raw/`. The project does not include the dataset because it is large and has its own distribution terms.

Expected files include:
- `olist_orders_dataset.csv`
- `olist_order_items_dataset.csv`
- `olist_products_dataset.csv`
- `olist_customers_dataset.csv`
- `olist_order_reviews_dataset.csv`
- `olist_sellers_dataset.csv`
- `product_category_name_translation.csv`

## Quick start

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python scripts/check_data.py
```

Open `notebooks/01_business_analysis.ipynb` in Jupyter Notebook or VS Code and run the cells from top to bottom.

## Repository structure

```text
ecommerce-business-analytics/
├── data/
│   ├── raw/                 # Downloaded source CSVs (not committed)
│   └── processed/           # Cleaned outputs (not committed)
├── notebooks/
│   └── 01_business_analysis.ipynb
├── reports/
│   └── analysis_plan.md
├── scripts/
│   └── check_data.py
├── sql/
│   └── starter_queries.sql
├── .gitignore
└── requirements.txt
```

## Current scope

This is a starter project. It deliberately keeps the first version focused on core Python and pandas rather than pretending to have results before the data has been downloaded and analyzed. Add charts, validated findings, and a concise business recommendation after completing the notebook.

## Good portfolio practice

- Do not invent findings or business impact.
- Keep raw data out of Git.
- Explain any data cleaning decisions.
- Include chart titles, labels, units, and date ranges.
- Update this README with your own verified results after completing the analysis.
