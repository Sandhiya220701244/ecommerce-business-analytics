"""Check whether the Olist CSV files needed for the analysis are present."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"

REQUIRED_FILES = [
    "olist_orders_dataset.csv",
    "olist_order_items_dataset.csv",
    "olist_products_dataset.csv",
    "olist_customers_dataset.csv",
    "olist_order_reviews_dataset.csv",
    "product_category_name_translation.csv",
]

def main():
    print(f"Checking data folder: {RAW}")
    missing = []
    for filename in REQUIRED_FILES:
        path = RAW / filename
        if not path.exists():
            missing.append(filename)
            print(f"[MISSING] {filename}")
            continue
        try:
            sample = pd.read_csv(path, nrows=5)
            print(f"[OK] {filename} | sample columns: {', '.join(sample.columns)}")
        except Exception as exc:
            print(f"[ERROR] {filename} could not be read: {exc}")
            missing.append(filename)

    if missing:
        print("\\nSome files are missing or unreadable.")
        print("Download the Olist dataset and place the CSVs in data/raw/.")
    else:
        print("\\nAll required files are present and readable.")

if __name__ == "__main__":
    main()
