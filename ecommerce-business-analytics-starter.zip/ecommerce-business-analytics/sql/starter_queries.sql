-- Optional SQL practice after loading the CSVs into a database.
-- Adjust table names and date syntax for your database.

-- 1. Orders by status
SELECT order_status, COUNT(*) AS order_count
FROM orders
GROUP BY order_status
ORDER BY order_count DESC;

-- 2. Monthly order volume (PostgreSQL syntax)
SELECT DATE_TRUNC('month', order_purchase_timestamp) AS purchase_month,
       COUNT(DISTINCT order_id) AS orders
FROM orders
GROUP BY 1
ORDER BY 1;

-- 3. Category revenue (join order_items to products)
SELECT p.product_category_name,
       SUM(oi.price) AS item_price_total
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
GROUP BY p.product_category_name
ORDER BY item_price_total DESC;
