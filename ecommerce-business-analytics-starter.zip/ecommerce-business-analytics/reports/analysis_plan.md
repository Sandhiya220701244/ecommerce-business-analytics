# Analysis Plan

## Objective
Understand sales performance, geographic demand, product-category contribution, and delivery experience in the Olist marketplace dataset.

## Tables to use
- Orders: order status and purchase/delivery timestamps
- Order items: price, freight value, product and seller identifiers
- Products: product category
- Customers: customer state
- Reviews: review score
- Category translation: English category names

## Metric definitions
- **Revenue (initial proxy):** sum of item `price`. State clearly that this excludes freight and is not necessarily recognized accounting revenue.
- **Order count:** distinct `order_id` values, with the order-status filter documented.
- **Average order value:** item-price total divided by distinct eligible orders.
- **Late delivery:** delivered timestamp is later than estimated delivery date. Exclude missing timestamps from the late-rate denominator and report exclusions.
- **Review score:** average review score; avoid claiming causation from descriptive comparisons.

## Cleaning checklist
1. Parse date columns as datetimes.
2. Check duplicate order and item keys.
3. Inspect missing delivery dates and order statuses.
4. Confirm join cardinality before merging tables.
5. Check negative or implausible price/freight values.
6. Record row counts before and after each filter.

## Suggested workflow
1. Inspect each CSV's shape, columns, data types, and missing values.
2. Build an order-level table for order dates and delivery outcomes.
3. Aggregate item prices to order level before joining to avoid double counting.
4. Join product category and customer state for segmentation.
5. Create monthly, category, state, and delivery analyses.
6. Visualize the results and write 3–5 evidence-backed observations.

## Questions to answer
- Is monthly order activity growing, declining, or seasonal?
- Which categories lead by item-price revenue?
- Which states lead by order count?
- What share of delivered orders arrived late?
- How do average review scores differ between on-time and late deliveries?

## Limitations to disclose
This is observational marketplace data. Associations do not establish causation. Explain exclusions, missing data, the chosen revenue proxy, and any join limitations.
